/**
 */
package FamiliesToPersons.Rules;

import org.eclipse.emf.ecore.EObject;

import org.moflon.tgg.runtime.AbstractRule;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Family Member2 Person</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see FamiliesToPersons.Rules.RulesPackage#getFamilyMember2Person()
 * @model
 * @generated
 */
public interface FamilyMember2Person extends EObject, AbstractRule { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // FamilyMember2Person
