/**
 */
package FamiliesToPersons.Rules.impl;

import FamiliesToPersons.Rules.ExistingFamily2Person;
import FamiliesToPersons.Rules.RulesPackage;

import org.eclipse.emf.ecore.EClass;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Existing Family2 Person</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class ExistingFamily2PersonImpl extends AbstractRuleImpl implements ExistingFamily2Person {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ExistingFamily2PersonImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.eINSTANCE.getExistingFamily2Person();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //ExistingFamily2PersonImpl
