/**
 */
package FamiliesToPersons.Rules.impl;

import FamiliesToPersons.Rules.FamilyMember2Person;
import FamiliesToPersons.Rules.RulesPackage;

import org.eclipse.emf.ecore.EClass;

import org.moflon.tgg.runtime.impl.AbstractRuleImpl;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Family Member2 Person</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class FamilyMember2PersonImpl extends AbstractRuleImpl implements FamilyMember2Person {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FamilyMember2PersonImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RulesPackage.eINSTANCE.getFamilyMember2Person();
	}
	// <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} //FamilyMember2PersonImpl
