/**
 */
package FamiliesToPersons.Rules;

import org.eclipse.emf.ecore.EObject;

import org.moflon.tgg.runtime.AbstractRule;
// <-- [user defined imports]
// [user defined imports] -->

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Existing Family2 Person</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see FamiliesToPersons.Rules.RulesPackage#getExistingFamily2Person()
 * @model
 * @generated
 */
public interface ExistingFamily2Person extends EObject, AbstractRule { // <-- [user code injected with eMoflon]

	// [user code injected with eMoflon] -->
} // ExistingFamily2Person
